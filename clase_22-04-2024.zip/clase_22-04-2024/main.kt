fun main() {
    var saludo: String = "Hola a todos!";
    var numero: Int? = 32;
    println(saludo + ' ' + numero);
    
    val nombre:String? = readLine();
    println(nombre);
    
    val edad = readLine();
    val valor = edad.toInt();
    println(valor);
}
