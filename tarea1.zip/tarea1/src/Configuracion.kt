//Creamos la interfaz para usarla en la clase estudiante y trabajador
interface Trabajador{
    public fun realizarTarea(){
    }
}

//Creamos la interfaz para usarla en la clase vendedor y gerente
interface emp {
    public fun CalcularSalario(){

    }
}